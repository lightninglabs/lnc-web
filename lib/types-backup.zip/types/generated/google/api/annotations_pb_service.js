// package: google.api
// file: google/api/annotations.proto

